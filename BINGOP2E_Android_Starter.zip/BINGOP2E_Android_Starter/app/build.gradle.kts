plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bingop2e.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bingop2e.mobile"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
